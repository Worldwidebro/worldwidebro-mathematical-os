# 🏛️ Master Capital Prospectus: HealthRoute Logistics LLC

```yaml
document_id: "DOC-LT005-001"
venture_id: "LT-005"
company_name: "HealthRoute Logistics LLC"
brand_name: "HealthRoute Courier"
jurisdiction: "North Carolina / Delaware"
naics_code: "492110 / 621511"
date_of_compilation: "2026-09-07"
confidentiality: "CONFIDENTIAL & PROPRIETARY"
target_facilities: "Healthcare CDFI Loan ($250K @ 4.25%) + Fleet Lease ($120K) + NIH SBIR ($300K)"
live_surface: "https://healthroute-courier.vercel.app"
repository: "Worldwidebro/lt-005-medical-courier-dispatch (Commit bdb61fb)"
```

---

## 1. Executive Summary
HealthRoute Logistics LLC operates **HealthRoute** (`https://healthroute-courier.vercel.app`), a dedicated HIPAA-compliant clinical specimen courier dispatch platform. HealthRoute connects community health centers, outpatient surgical clinics, and reference laboratories with vetted medical couriers equipped with continuous IoT cold-chain temperature telemetry (-20°C frozen, 2°–8°C refrigerated, ambient). By digitizing the medical logistics chain of custody, HealthRoute prevents pre-analytical specimen degradation, reduces lost sample rates to 0.0%, and guarantees <90 minute emergency STAT lab turnarounds.

---

## 2. The Clinical Disparity & Market Problem
* **70% of medical decisions depend on diagnostic laboratory testing.**
* **Up to 75% of lab errors happen during pre-analytical transit** due to temperature excursions, hemolysis, and specimen loss.
* Rural clinics and Federally Qualified Health Centers (FQHCs) lack dedicated hospital courier systems and are forced to rely on unmonitored rideshare drivers or paper dispatch logs, leading to diagnostic delays of 48–72 hours for cancer biopsies and blood cultures.

---

## 3. The HealthRoute Solution
* **Verified Codebase:** Production commit `bdb61fb` in `Worldwidebro/lt-005-medical-courier-dispatch`.
* **Continuous Thermal Telemetry:** Integrates BLE temperature probes with the driver mobile app, triggering real-time dispatcher alerts if specimens breach clinical temperature bounds.
* **Turnkey HIPAA Compliance:** Standard Business Associate Agreements (BAAs), chain-of-custody biometric signatures, and OSHA 1910.1030 bloodborne pathogen handling protocols.

---

## 4. Traction & Signed LOI Backlog
* **Commercial Pricing Live:** Standard Scheduled Pickup (\$45), STAT Emergency Rush (\$85), Clinic Retainer (\$1,200/mo).
* **Documented LOI Pipeline:**
  - *Triad Community Health Network (`LOI-LT005-001`):* \$57,600 LOI (4 rural FQHC clinic retainers at \$1,200/mo).
  - *Carolina BioPathology Reference Laboratories (`LOI-LT005-002`):* \$180,000 master routing agreement for STAT urgent deliveries.
* **Total LOI Pipeline:** **\$237,600** (Weighted Value: **\$174,960**).

---

## 5. Three-Year Pro Forma Financial Summary

```text
CONSOLIDATED REVENUE & CASH FLOW STATEMENT (USD)
───────────────────────────────────────────────────────────────────────────────
METRIC                              YEAR 1 (2027)   YEAR 2 (2028)   YEAR 3 (2029)
───────────────────────────────────────────────────────────────────────────────
Active Retainer Clinics ($1,200/mo)            15              45             110
Completed STAT & Scheduled Pickups          8,500          24,000          58,000

Clinic Retainer Revenue ($1,200/mo)      $216,000        $648,000      $1,584,000
Per-Pickup Delivery Revenue ($45/$85)    $467,500      $1,320,000      $3,190,000
TOTAL GROSS REVENUE                      $683,500      $1,968,000      $4,774,000

Driver Contractor Payments & Fuel       ($396,400)    ($1,121,700)    ($2,673,400)
GROSS PROFIT                             $287,100        $846,300      $2,100,600
Gross Margin                                42.0%           43.0%           44.0%

Operating Expenses (Insurance, SG&A)    ($155,000)      ($385,000)      ($720,000)
OPERATING INCOME (EBITDA)                $132,100        $461,300      $1,380,600

Total Annual Debt Service (CDFI + Lease)($76,000)       ($76,000)       ($76,000)
NET CASH FLOW AFTER DEBT SERVICE          $56,100        $385,300      $1,304,600
DEBT SERVICE COVERAGE RATIO (DSCR)          1.74x           6.07x          18.17x
───────────────────────────────────────────────────────────────────────────────
```

---

## 6. Sources & Uses of Capital (\$370,000 Total)

| Category | Allocation ($) | Detailed Use of Funds |
| :--- | :--- | :--- |
| **Fleet Lease (2 Reefer Vans)** | \$120,000 | 2 Ford Transit 250 vans equipped with Thermo King dual-zone units |
| **Fleet Down Payment & Outfitting** | \$70,000 | Custom medical shelving, backup batteries, NIST dataloggers |
| **Clinical Operations Runway** | \$110,000 | 90-Day reserves for lead medical dispatcher and 4 certified drivers |
| **HIPAA & Insurance Umbrella** | \$45,000 | \$5,000,000 healthcare transport liability policy & third-party audit |
| **Closing Costs & Legal** | \$25,000 | CDFI origination fees and regulatory filings |
| **TOTAL USES** | **\$370,000** | **Fully Reconciled with Capital Facilities Registry** |
